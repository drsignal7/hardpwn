#!/usr/bin/env python3
import argparse
import sys
from hardpwn.autoprober.autoprober import AutoProber
from hardpwn.firmflasher.flasher import FirmFlasher
from hardpwn.glitchlab.glitchlab import GlitchLab
from hardpwn.utils.db import HardpwnDB

def main():
    parser = argparse.ArgumentParser(description="HardPwn Orchestrator")
    parser.add_argument("action", choices=["probe", "recon", "flash", "glitch"], help="Action to perform")
    parser.add_argument("--transport", choices=["pi", "pico"], required=True, help="Transport to use")
    parser.add_argument("--port", help="Serial port for Pico")
    args = parser.parse_args()

    db = HardpwnDB("results/hardpwn.db")

    if args.action == "probe":
        ap = AutoProber(args.transport, args.port, db)
        ap.run_probe()
    elif args.action == "recon":
        ap = AutoProber(args.transport, args.port, db)
        ap.run_recon()
    elif args.action == "flash":
        ff = FirmFlasher(args.transport, args.port, db)
        ff.dump_firmware()
    elif args.action == "glitch":
        gl = GlitchLab(args.transport, args.port, db)
        gl.run_glitch()
    else:
        print("Invalid action")

if __name__ == "__main__":
    main()
