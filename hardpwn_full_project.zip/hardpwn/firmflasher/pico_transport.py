import serial, time

class PicoFlasher:
    def __init__(self, port):
        self.ser = serial.Serial(port,115200,timeout=5)
        time.sleep(2)

    def read_flash(self):
        self.ser.write(b"dump\n")
        size_line = self.ser.readline().decode().strip()
        size = int(size_line)
        data = self.ser.read(size)
        return data
