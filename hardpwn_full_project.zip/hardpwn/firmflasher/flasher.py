import os, time
from hardpwn.firmflasher.pigpio_transport import PiFlasher
from hardpwn.firmflasher.pico_transport import PicoFlasher

class FirmFlasher:
    def __init__(self, transport, port, db):
        self.db = db
        if transport == "pi":
            self.dev = PiFlasher()
        elif transport == "pico":
            self.dev = PicoFlasher(port)
        else:
            raise ValueError("Unsupported transport")

    def dump_firmware(self):
        print("[*] Dumping firmware...")
        dumpfile = f"results/dumps/firmware_{int(time.time())}.bin"
        data = self.dev.read_flash()
        with open(dumpfile,"wb") as f: f.write(data)
        self.db.log_firmware(dumpfile,len(data))
        print(f"[+] Firmware dumped to {dumpfile}, size={len(data)} bytes")
