import spidev

class PiFlasher:
    def __init__(self):
        self.spi = spidev.SpiDev()
        self.spi.open(0,0)
        self.spi.max_speed_hz = 500000

    def read_flash(self, size=1024*1024):
        data = bytearray()
        self.spi.xfer2([0x03,0,0,0]) # read command start
        for i in range(size):
            data.extend(self.spi.readbytes(1))
        return data
