import sqlite3, json, os, time

class HardpwnDB:
    def __init__(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.conn=sqlite3.connect(path)
        self.init_schema()

    def init_schema(self):
        c=self.conn.cursor()
        c.execute("CREATE TABLE IF NOT EXISTS interfaces(type TEXT, pins TEXT, ts REAL)")
        c.execute("CREATE TABLE IF NOT EXISTS chips(name TEXT, ts REAL)")
        c.execute("CREATE TABLE IF NOT EXISTS firmware(path TEXT, size INT, ts REAL)")
        c.execute("CREATE TABLE IF NOT EXISTS glitches(iter INT, success INT, ts REAL)")
        self.conn.commit()

    def log_interface(self, typ, pins):
        self.conn.execute("INSERT INTO interfaces VALUES(?,?,?)",(typ,json.dumps(pins),time.time()))
        self.conn.commit()

    def log_chip(self, chip):
        self.conn.execute("INSERT INTO chips VALUES(?,?)",(chip,time.time()))
        self.conn.commit()

    def log_firmware(self, path, size):
        self.conn.execute("INSERT INTO firmware VALUES(?,?,?)",(path,size,time.time()))
        self.conn.commit()

    def log_glitch(self, iteration, success):
        self.conn.execute("INSERT INTO glitches VALUES(?,?,?)",(iteration,int(success),time.time()))
        self.conn.commit()
