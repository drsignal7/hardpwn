import time
from hardpwn.glitchlab.pigpio_glitch_transport import PiGlitcher
from hardpwn.glitchlab.pico_glitch_transport import PicoGlitcher

class GlitchLab:
    def __init__(self, transport, port, db):
        self.db = db
        if transport == "pi":
            self.dev = PiGlitcher()
        elif transport == "pico":
            self.dev = PicoGlitcher(port)
        else:
            raise ValueError("Unsupported transport")

    def run_glitch(self, attempts=5):
        print("[*] Running glitch experiments...")
        results = []
        for i in range(attempts):
            success = self.dev.inject_glitch(i*10)
            results.append((i,success))
            self.db.log_glitch(i,success)
        print("[+] Glitch results:",results)
