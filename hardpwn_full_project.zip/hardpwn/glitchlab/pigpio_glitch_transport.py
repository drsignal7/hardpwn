import RPi.GPIO as GPIO, time

class PiGlitcher:
    def __init__(self):
        self.pin=18
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(self.pin,GPIO.OUT)

    def inject_glitch(self, delay_us):
        time.sleep(delay_us/1e6)
        GPIO.output(self.pin,1)
        time.sleep(0.000001)
        GPIO.output(self.pin,0)
        return True
