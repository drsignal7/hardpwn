import serial, time

class PicoGlitcher:
    def __init__(self, port):
        self.ser = serial.Serial(port,115200,timeout=2)
        time.sleep(2)

    def inject_glitch(self, delay_us):
        cmd=f"glitch {delay_us}\n"
        self.ser.write(cmd.encode())
        out=self.ser.readline().decode().strip()
        return out=="OK"
