import spidev, serial, smbus, subprocess

class PiTransport:
    def __init__(self):
        pass

    def detect_interfaces(self):
        found = {}
        try:
            spi = spidev.SpiDev()
            spi.open(0,0)
            found['SPI'] = {'bus':0,'cs':0}
            spi.close()
        except Exception: pass
        try:
            bus = smbus.SMBus(1)
            bus.close()
            found['I2C'] = {'bus':1}
        except Exception: pass
        try:
            subprocess.run(['openocd','--version'], check=True)
            found['JTAG'] = {'tool':'openocd'}
        except Exception: pass
        found['UART'] = {'tx':14,'rx':15}
        return found

    def detect_chips(self):
        return ['GenericSPIFlash','GenericI2CPeripheral']
