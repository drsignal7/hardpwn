import serial, time, json

class PicoTransport:
    def __init__(self, port):
        self.ser = serial.Serial(port,115200,timeout=2)
        time.sleep(2)

    def _cmd(self, cmd):
        self.ser.write((cmd+"\n").encode())
        return self.ser.readline().decode().strip()

    def detect_interfaces(self):
        self.ser.write(b"detect\n")
        out = self.ser.readline().decode().strip()
        try:
            return json.loads(out)
        except:
            return {}

    def detect_chips(self):
        self.ser.write(b"chips\n")
        out = self.ser.readline().decode().strip()
        try:
            return json.loads(out)
        except:
            return []
