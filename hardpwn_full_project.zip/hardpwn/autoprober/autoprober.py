import time
from hardpwn.autoprober.pigpio_transport import PiTransport
from hardpwn.autoprober.pico_transport import PicoTransport

class AutoProber:
    def __init__(self, transport, port, db):
        self.db = db
        if transport == "pi":
            self.dev = PiTransport()
        elif transport == "pico":
            self.dev = PicoTransport(port)
        else:
            raise ValueError("Unsupported transport")

    def run_probe(self):
        print("[*] Probing DUT for interfaces...")
        found = self.dev.detect_interfaces()
        for iface, pins in found.items():
            self.db.log_interface(iface, pins)
        print("[+] Interfaces detected:", found)

    def run_recon(self):
        print("[*] Reconnaissance on detected chips...")
        chips = self.dev.detect_chips()
        for chip in chips:
            self.db.log_chip(chip)
        print("[+] Chips detected:", chips)
