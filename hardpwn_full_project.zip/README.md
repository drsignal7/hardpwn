# HardPwn Full Project
Usage:
  python3 main.py probe --transport pi
  python3 main.py recon --transport pico --port /dev/ttyACM0
  python3 main.py flash --transport pi
  python3 main.py glitch --transport pico --port /dev/ttyACM0
